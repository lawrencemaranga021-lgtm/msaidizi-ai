import AsyncStorage from "@react-native-async-storage/async-storage";

const BASE = process.env.EXPO_PUBLIC_API_URL || "http://localhost:3000";

export async function api(path:string, method="GET", body?:any){
  const token=await AsyncStorage.getItem("msaidizi_token");
  const res=await fetch(BASE+path,{method,headers:{"Content-Type":"application/json",...(token?{Authorization:`Bearer ${token}`}:{})},body:body?JSON.stringify(body):undefined});
  const data=await res.json().catch(()=>({}));
  if(!res.ok) throw new Error(data.error||data.message||`Request failed (${res.status})`);
  return data;
}