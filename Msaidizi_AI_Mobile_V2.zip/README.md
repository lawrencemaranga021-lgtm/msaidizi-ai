# Msaidizi AI Mobile V2

Android/iOS React Native app built with Expo and connected to the Msaidizi AI V1.2 backend.

## 1. Install

Node.js LTS is required.

```bash
npm install
```

## 2. Configure the backend URL

Create `.env` from `.env.example`.

For a physical Android phone, do NOT use `localhost`. Use your computer's LAN IP, for example:

```env
EXPO_PUBLIC_API_URL=http://192.168.1.20:3000
```

The phone and computer should normally be on the same Wi-Fi network.

## 3. Start

```bash
npx expo start
```

Install Expo Go on the Android phone and scan the QR code.

## 4. Connect to the existing backend

Start the Msaidizi AI V1.2 backend first:

```bash
npm install
npm start
```

Then make sure the mobile `.env` points to that computer's IP.

## 5. Production Android build

After testing, configure EAS and build an Android binary:

```bash
npm install --global eas-cli
eas login
eas build:configure
eas build --platform android
```

For Google Play distribution, create a production Android App Bundle and submit it through EAS/Google Play Console.

## Included in this V2

- Login
- Registration
- Persistent auth token
- Home dashboard
- AI chat
- Tasks
- Reminders
- Profile/logout
- Connection to the V1.2 REST API
- Msaidizi AI branding

This project intentionally keeps the OpenAI API key on the backend.
