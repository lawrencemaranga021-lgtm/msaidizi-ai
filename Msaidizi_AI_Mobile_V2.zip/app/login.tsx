import React, {useState} from "react";
import {Alert, Pressable, SafeAreaView, StyleSheet, Text, TextInput, View} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import {router} from "expo-router";
import {api} from "../src/api";

export default function Login(){
 const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [loading,setLoading]=useState(false);
 async function submit(){
  setLoading(true);
  try { const data=await api("/api/login","POST",{email,password}); await AsyncStorage.setItem("msaidizi_token",data.token); router.replace("/home"); }
  catch(e:any){Alert.alert("Login failed",e.message)} finally{setLoading(false)}
 }
 return <SafeAreaView style={s.safe}><View style={s.card}>
  <Text style={s.logo}>Msaidizi AI ✦</Text><Text style={s.tag}>Your Life. Smarter.</Text>
  <Text style={s.title}>Welcome back</Text>
  <TextInput placeholder="Email" autoCapitalize="none" keyboardType="email-address" style={s.input} value={email} onChangeText={setEmail}/>
  <TextInput placeholder="Password" secureTextEntry style={s.input} value={password} onChangeText={setPassword}/>
  <Pressable style={s.button} onPress={submit} disabled={loading}><Text style={s.buttonText}>{loading?"Signing in…":"Sign in"}</Text></Pressable>
  <Pressable onPress={()=>router.push("/register")}><Text style={s.link}>Create an account</Text></Pressable>
 </View></SafeAreaView>
}
const s=StyleSheet.create({safe:{flex:1,backgroundColor:"#F7F9FC",justifyContent:"center",padding:22},card:{backgroundColor:"#fff",padding:24,borderRadius:24},logo:{fontSize:28,fontWeight:"800",color:"#0B1F44"},tag:{color:"#6C3CFF",marginTop:4,marginBottom:30},title:{fontSize:24,fontWeight:"700",color:"#0B1F44",marginBottom:18},input:{borderWidth:1,borderColor:"#DCE2EC",borderRadius:14,padding:14,marginBottom:12,fontSize:16},button:{backgroundColor:"#0B1F44",padding:15,borderRadius:14,alignItems:"center",marginTop:4},buttonText:{color:"#fff",fontWeight:"700",fontSize:16},link:{color:"#6C3CFF",textAlign:"center",marginTop:18,fontWeight:"600"}});