import React,{useEffect,useState} from "react";
import {Alert,Pressable,SafeAreaView,StyleSheet,Text,View} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import {router} from "expo-router";
import {api} from "../src/api";

export default function Profile(){const [me,setMe]=useState<any>();useEffect(()=>{api("/api/me").then(setMe).catch(()=>{})},[]);
 async function logout(){await AsyncStorage.removeItem("msaidizi_token");router.replace("/login")}
 return <SafeAreaView style={s.safe}><View style={s.content}><Text style={s.title}>Profile</Text><View style={s.card}><Text style={s.label}>Name</Text><Text style={s.value}>{me?.name||"—"}</Text><Text style={s.label}>Email</Text><Text style={s.value}>{me?.email||"—"}</Text></View><Pressable style={s.logout} onPress={logout}><Text style={s.logoutText}>Sign out</Text></Pressable></View></SafeAreaView>}
const s=StyleSheet.create({safe:{flex:1,backgroundColor:"#F7F9FC"},content:{padding:20},title:{fontSize:28,fontWeight:"800",color:"#0B1F44",marginBottom:20},card:{backgroundColor:"#fff",padding:20,borderRadius:18},label:{fontSize:12,color:"#667085",marginTop:8},value:{fontSize:17,color:"#172033",fontWeight:"600",marginTop:3},logout:{marginTop:20,borderWidth:1,borderColor:"#D92D20",padding:15,borderRadius:14,alignItems:"center"},logoutText:{color:"#D92D20",fontWeight:"700"}});