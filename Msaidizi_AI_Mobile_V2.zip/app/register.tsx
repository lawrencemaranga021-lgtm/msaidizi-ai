import React,{useState} from "react";
import {Alert,Pressable,SafeAreaView,StyleSheet,Text,TextInput,View} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import {router} from "expo-router";
import {api} from "../src/api";

export default function Register(){
 const [name,setName]=useState("");const [email,setEmail]=useState("");const [password,setPassword]=useState("");const [loading,setLoading]=useState(false);
 async function submit(){setLoading(true);try{const d=await api("/api/register","POST",{name,email,password});await AsyncStorage.setItem("msaidizi_token",d.token);router.replace("/home")}catch(e:any){Alert.alert("Registration failed",e.message)}finally{setLoading(false)}}
 return <SafeAreaView style={s.safe}><View style={s.card}><Text style={s.logo}>Msaidizi AI ✦</Text><Text style={s.title}>Create your account</Text>
 <TextInput placeholder="Name" style={s.input} value={name} onChangeText={setName}/><TextInput placeholder="Email" autoCapitalize="none" style={s.input} value={email} onChangeText={setEmail}/><TextInput placeholder="Password (8+ characters)" secureTextEntry style={s.input} value={password} onChangeText={setPassword}/>
 <Pressable style={s.button} onPress={submit} disabled={loading}><Text style={s.buttonText}>{loading?"Creating…":"Create account"}</Text></Pressable><Pressable onPress={()=>router.back()}><Text style={s.link}>Back to sign in</Text></Pressable></View></SafeAreaView>
}
const s=StyleSheet.create({safe:{flex:1,backgroundColor:"#F7F9FC",justifyContent:"center",padding:22},card:{backgroundColor:"#fff",padding:24,borderRadius:24},logo:{fontSize:28,fontWeight:"800",color:"#0B1F44",marginBottom:26},title:{fontSize:24,fontWeight:"700",color:"#0B1F44",marginBottom:18},input:{borderWidth:1,borderColor:"#DCE2EC",borderRadius:14,padding:14,marginBottom:12,fontSize:16},button:{backgroundColor:"#0B1F44",padding:15,borderRadius:14,alignItems:"center"},buttonText:{color:"#fff",fontWeight:"700"},link:{color:"#6C3CFF",textAlign:"center",marginTop:18,fontWeight:"600"}});