import React,{useEffect,useState} from "react";
import {Alert,Pressable,SafeAreaView,ScrollView,StyleSheet,Text,View} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import {router} from "expo-router";
import {api} from "../src/api";

export default function Home(){
 const [me,setMe]=useState<any>(null);const [tasks,setTasks]=useState<any[]>([]);
 useEffect(()=>{(async()=>{try{setMe(await api("/api/me"));setTasks(await api("/api/tasks"))}catch(e){await AsyncStorage.removeItem("msaidizi_token");router.replace("/login")}})()},[]);
 return <SafeAreaView style={s.safe}><ScrollView contentContainerStyle={s.content}>
 <Text style={s.logo}>Msaidizi AI ✦</Text><Text style={s.greet}>Hello{me?.name?", "+me.name:""} 👋</Text><Text style={s.sub}>What can I help you with today?</Text>
 <View style={s.grid}><Card title="AI Chat" icon="💬" onPress={()=>router.push("/chat")}/><Card title="Tasks" icon="✓" onPress={()=>router.push("/tasks")}/><Card title="Reminders" icon="⏰" onPress={()=>router.push("/reminders")}/><Card title="Profile" icon="👤" onPress={()=>router.push("/profile")}/></View>
 <View style={s.panel}><Text style={s.panelTitle}>Today's tasks</Text>{tasks.slice(0,5).map(t=><View key={t.id} style={s.row}><Text style={s.dot}>•</Text><Text style={s.task}>{t.title}</Text></View>)}{tasks.length===0&&<Text style={s.muted}>No tasks yet. Ask Msaidizi to create one.</Text>}</View>
 </ScrollView></SafeAreaView>
}
function Card({title,icon,onPress}:any){return <Pressable style={s.card} onPress={onPress}><Text style={s.icon}>{icon}</Text><Text style={s.cardTitle}>{title}</Text></Pressable>}
const s=StyleSheet.create({safe:{flex:1,backgroundColor:"#F7F9FC"},content:{padding:20},logo:{fontSize:25,fontWeight:"800",color:"#0B1F44"},greet:{fontSize:28,fontWeight:"800",color:"#0B1F44",marginTop:28},sub:{fontSize:16,color:"#667085",marginTop:6,marginBottom:22},grid:{flexDirection:"row",flexWrap:"wrap",gap:12},card:{width:"47%",backgroundColor:"#fff",padding:20,borderRadius:20,minHeight:120,justifyContent:"center"},icon:{fontSize:28,marginBottom:12},cardTitle:{fontSize:17,fontWeight:"700",color:"#0B1F44"},panel:{backgroundColor:"#fff",padding:20,borderRadius:20,marginTop:18},panelTitle:{fontSize:18,fontWeight:"800",color:"#0B1F44",marginBottom:12},row:{flexDirection:"row",paddingVertical:8},dot:{color:"#6C3CFF",fontSize:20,marginRight:8},task:{fontSize:15,color:"#344054"},muted:{color:"#667085"}});