import React, { useEffect, useState } from "react";
import { ActivityIndicator, View } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { router } from "expo-router";

export default function Index() {
  const [ready, setReady] = useState(false);

  useEffect(() => {
    AsyncStorage.getItem("msaidizi_token").then(token => {
      router.replace(token ? "/home" : "/login");
      setReady(true);
    });
  }, []);

  if (!ready) return <View style={{flex:1,alignItems:"center",justifyContent:"center"}}><ActivityIndicator /></View>;
  return null;
}