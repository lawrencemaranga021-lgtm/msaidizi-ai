import React,{useEffect,useState} from "react";
import {Alert,SafeAreaView,ScrollView,StyleSheet,Text,View} from "react-native";
import {api} from "../src/api";

export default function Reminders(){const [items,setItems]=useState<any[]>([]);useEffect(()=>{api("/api/reminders").then(setItems).catch(e=>Alert.alert("Error",e.message))},[]);
 return <SafeAreaView style={s.safe}><ScrollView contentContainerStyle={s.content}><Text style={s.title}>Reminders</Text>{items.map(r=><View key={r.id} style={s.card}><Text style={s.name}>⏰ {r.title}</Text><Text style={s.time}>{r.remind_at||"Scheduled reminder"}</Text></View>)}{!items.length&&<Text style={s.muted}>No reminders yet. You can ask Msaidizi to create one.</Text>}</ScrollView></SafeAreaView>}
const s=StyleSheet.create({safe:{flex:1,backgroundColor:"#F7F9FC"},content:{padding:20},title:{fontSize:28,fontWeight:"800",color:"#0B1F44",marginBottom:20},card:{backgroundColor:"#fff",padding:18,borderRadius:18,marginBottom:10},name:{fontSize:16,fontWeight:"700",color:"#172033"},time:{marginTop:6,color:"#667085"},muted:{color:"#667085"}});